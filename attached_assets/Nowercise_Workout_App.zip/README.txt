Nowercise 4-Week Workout App
----------------------------

This project contains all 12 workout log pages and the interactive calendar homepage.

To use in Replit:
1. Create a new Replit project using the HTML, CSS, JS template.
2. Upload all files in this ZIP to your Replit workspace.
3. Replace 'https://your-replit-username.replit.app/' in index.html with your actual Replit project URL.
4. Click "Run" to launch the calendar app.
5. Clients can click any date to view and log that day’s session. Logs will be sent via EmailJS.

Includes:
- index.html = Main calendar page
- day1.html through day12.html = Each workout page
- README.txt = This guide

Make sure your EmailJS service is active to receive workout logs.

— Built with care for Nowercise 💪
